/* eslint-disable no-console */

$(document).ready(function() {
  if (console && console.log) {
    console.log('############################################');
    console.log('# Hi there technical person,');
    console.log('# ');
    console.log('# We\'d love your help ');
    console.log('# **** Pushing Open Source Forward **** ');
    console.log('# Get in touch: ');
    console.log('# - http://github.com/gitcoinco');
    console.log('# - founders@gitcoin.co');
    console.log('# Turnaround a Funded Issue: ');
    console.log('# - https://gitcoin.co/explorer');
    console.log('# ');
    console.log('# <3 ');
    console.log('# Gitcoin Core');
    console.log('############################################');
  }
});
